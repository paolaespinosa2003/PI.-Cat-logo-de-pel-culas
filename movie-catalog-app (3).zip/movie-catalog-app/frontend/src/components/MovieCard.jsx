
import React from 'react';

export default function MovieCard({ movie, onClick }) {
  return (
    <div onClick={onClick} style={{ border: '1px solid #ccc', margin: '10px', padding: '10px' }}>
      <h3>{movie.title}</h3>
      <img src={movie.imageUrl} alt={movie.title} width="200" />
    </div>
  );
}
