
import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Admin() {
  const [movies, setMovies] = useState([]);
  const [form, setForm] = useState({ title: '', year: '', director: '', genre: '', synopsis: '', imageUrl: '' });

  useEffect(() => {
    axios.get('http://localhost:5000/api/movies').then(res => setMovies(res.data));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/api/movies', form).then(() => window.location.reload());
  };

  const handleDelete = (id) => {
    axios.delete(`http://localhost:5000/api/movies/${id}`).then(() => window.location.reload());
  };

  return (
    <div>
      <h2>Administrar Películas</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Título" onChange={e => setForm({ ...form, title: e.target.value })} />
        <input placeholder="Año" onChange={e => setForm({ ...form, year: e.target.value })} />
        <input placeholder="Director" onChange={e => setForm({ ...form, director: e.target.value })} />
        <input placeholder="Género" onChange={e => setForm({ ...form, genre: e.target.value })} />
        <input placeholder="Sinopsis" onChange={e => setForm({ ...form, synopsis: e.target.value })} />
        <input placeholder="URL de imagen" onChange={e => setForm({ ...form, imageUrl: e.target.value })} />
        <button type="submit">Agregar Película</button>
      </form>
      <ul>
        {movies.map(m => (
          <li key={m._id}>{m.title} <button onClick={() => handleDelete(m._id)}>Eliminar</button></li>
        ))}
      </ul>
    </div>
  );
}
