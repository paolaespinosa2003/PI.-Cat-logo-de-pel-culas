
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import MovieCard from '../components/MovieCard';
import { useNavigate } from 'react-router-dom';

export default function Catalog() {
  const [movies, setMovies] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://localhost:5000/api/movies').then(res => setMovies(res.data));
  }, []);

  return (
    <div>
      <h2>Catálogo de Películas</h2>
      {movies.map(movie => (
        <MovieCard key={movie._id} movie={movie} onClick={() => navigate(`/movie/${movie._id}`)} />
      ))}
    </div>
  );
}
