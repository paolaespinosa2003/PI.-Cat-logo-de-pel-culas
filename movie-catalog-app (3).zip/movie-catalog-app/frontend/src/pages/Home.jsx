
import React from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div>
      <h1>Bienvenido al Catálogo de Películas</h1>
      <Link to="/register">Registrarse</Link> | <Link to="/login">Iniciar Sesión</Link>
    </div>
  );
}
