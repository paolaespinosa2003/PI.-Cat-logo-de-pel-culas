
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default function MovieDetails() {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/api/movies/${id}`).then(res => setMovie(res.data));
  }, [id]);

  if (!movie) return <div>Cargando...</div>;

  return (
    <div>
      <h2>{movie.title}</h2>
      <img src={movie.imageUrl} alt={movie.title} width="300" />
      <p><strong>Año:</strong> {movie.year}</p>
      <p><strong>Director:</strong> {movie.director}</p>
      <p><strong>Género:</strong> {movie.genre}</p>
      <p><strong>Sinopsis:</strong> {movie.synopsis}</p>
    </div>
  );
}
